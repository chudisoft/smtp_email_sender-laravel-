<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;

use PHPMailer\PHPMailer\PHPMailer;  
use PHPMailer\PHPMailer\Exception;

class EmailController extends Controller
{
    /**
    * Handle an authentication attempt.
    *
    * @param  \Illuminate\Http\Request $request
    *
    * @return Response
    */
    public function send_mail(Request $request)
    {
        $request->validate([
            'subject' => 'required|max:150|min:2',
            'to' => 'required|email|max:100|min:10',
            'message' => 'required|max:3500|min:55',
        ]);

        
        // $testMailData = [
        //     'title' => 'Test Email From AllPHPTricks.com',
        //     'body' => 'This is the body of test email.'
        // ];

        // Mail::to('your_email@gmail.com')->send(new SendMail($testMailData));

        // dd('Success! Email has been sent successfully.');
        
        require base_path("vendor/autoload.php");
        $mail = new PHPMailer(true);     // Passing `true` enables exceptions
        
        try {
 
            // Email server settings
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host = env('MAIL_HOST', ''); //'smtp.example.com';             //  smtp host
            $mail->SMTPAuth = true;
            $mail->Username = env('MAIL_USERNAME', '');   //  sender username
            $mail->Password = env('MAIL_PASSWORD', ''); // sender password
            $mail->SMTPSecure = 'tls';                  // encryption - ssl/tls
            $mail->Port = env('MAIL_PORT', 587);                          // port - 587/465
 
            $mail->setFrom(env('MAIL_FROM_ADDRESS', ''), 
                env('MAIL_FROM_NAME', ''));
            $mail->addAddress($request->to);
            // $mail->addCC($request->emailCc);
            // $mail->addBCC($request->emailBcc);
 
            $mail->addReplyTo(env('MAIL_FROM_ADDRESS', ''), 'Support');
 
            if(isset($_FILES['emailAttachments'])) {
                for ($i=0; $i < count($_FILES['emailAttachments']['tmp_name']); $i++) {
                    $mail->addAttachment($_FILES['emailAttachments']['tmp_name'][$i], $_FILES['emailAttachments']['name'][$i]);
                }
            }
 
 
            $mail->isHTML(true);                // Set email content format to HTML
 
            $mail->Subject = $request->subject;
            $mail->Body    = $request->message;
 
            // $mail->AltBody = plain text version of email body;
 
            if( !$mail->send() ) {
                return back()->with("failed", "Email not sent.")->withErrors($mail->ErrorInfo);
            }
            
            else {
                return back()->with("success", "Email has been sent.");
            }
 
        } catch (Exception $e) {
             return back()->with('error','Message could not be sent.');
        }
    }
}
